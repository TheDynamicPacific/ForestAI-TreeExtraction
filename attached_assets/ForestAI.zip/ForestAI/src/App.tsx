import IntegratedSystem from './components/IntegratedSystem';

function App() {
  return (
    <IntegratedSystem />
  );
}

export default App;